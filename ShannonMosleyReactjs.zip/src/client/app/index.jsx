import React from 'react';
import {render} from 'react-dom';
import axios from 'axios';
import apiStuff from './apikey.js';
import {MD5} from './md5build.js';
import dateFormat from 'dateformat';

class AlphabetList extends React.Component{
	constructor(props) {
    	super(props);
	    this.state = {
	    	//create an arrray from A to Z
			alphabets : [...Array(26)].map((q,w)=>String.fromCharCode(w+97))
	    };
	}
	render(){
		//create a list with A to Z
		const listAlphabet = this.state.alphabets.map((alphabet, index) =>{
	      return (
	      		<li 
	      		onClick={() => {this.props.onClick(index,"character","http://gateway.marvel.com/v1/public/characters")}}
	      		key={alphabet.toString()}> 
	      			{alphabet} 
	      		</li>
	      	)
	    });
		return (
			<div className="pl-md-0 col-sm-6 col-md-2 col-lg-1">
		        <ul className="main-browser">
		          {listAlphabet}
		        </ul>
		    </div>
		);
	}
}

//List out all of the characters after a letter is choosen
class CharacterListChildren extends React.Component {
	constructor(props) {
    	super(props);
	    this.state = {
	    };
	}
    render () {
        return (
        	<li onClick={(e) => {e.stopPropagation(); this.props.onClick(0,"comic",this.props.comics);}}>{this.props.name}</li>
        );
    }
}

class CharacterListContainer extends React.Component{
	constructor(props) {
    	super(props);
	    this.state = {
	    };
	}
	render(){
		const characters = []
		let someReturn = true
		if("no" in this.props.selectedCharacters){
			someReturn = false
		}else{
			for (let i = 0; i < this.props.selectedCharacters.length; i += 1) {
	            characters.push(<CharacterListChildren onClick={this.props.onClick.bind(this)} id={this.props.selectedCharacters[i].id} key={this.props.selectedCharacters[i]. id.toString()} name={this.props.selectedCharacters[i].name} comics={this.props.selectedCharacters[i].comics.collectionURI} />);
	        };
	    }
		return(
			<div className="pl-md-0 col-sm-6 col-md-3">
				<ul className="characters">
					{someReturn ? characters.length > 0 ? characters : this.props.charactersLoading : this.props.selectedCharacters.no}
				</ul>
			</div>
		)
	}
}

//List out all the comics of a choosen character
class ComicListChildren extends React.Component {
	constructor(props) {
    	super(props);
	    this.state = {
	    };
	}
    render () {
        return (
        	<div className="row comic-row">
        		<div className="col-12">
		        	<div className="row comic-top">
		        		<div className="col-md-2 col-lg-1 comic-title">
		        			Title:
		        		</div>
			        	<div className="col-md-6 col-lg-7 comic-title">
			        		{this.props.title}
			        	</div>
			        	<div className="col-4 comic-id">
			        		ID: {this.props.id}
			        	</div>
			        </div>
			       <div className="row">
			        	<div className="col-6 comic-date">
			        		Release Date: {this.props.release}
			        	</div>
			        	{this.props.issue > 0 &&
							<div className="col-6 comic-issue">
				        		Issue Number: {this.props.issue}
				        	</div>
			        	}
		        	</div>
		        </div>
        	</div>
        );
    }
}

class ComicsContainer extends React.Component{
	constructor(props) {
    	super(props);
	    this.state = {
	    };
	}
	render(){
		const comics = []
		let someReturn = true
		if("no" in this.props.selectedComics){
			someReturn = false
		}else{
			for (let i = 0; i < this.props.selectedComics.length; i += 1) {
				let formateDate = dateFormat(this.props.selectedComics[i].dates[0].date, "mmm d, yyyy")
	            comics.push(<ComicListChildren id={this.props.selectedComics[i].id} key={this.props.selectedComics[i].id.toString()} title={this.props.selectedComics[i].title} issue={this.props.selectedComics[i].issueNumber} release={formateDate} />);
	        };
	    }
		return(
			<div className="mx-3 mx-md-0 col-md-7 col-lg-8 comic-container">
			{someReturn ? comics.length > 0 ? comics : this.props.comicsLoading : this.props.selectedComics.no}
			</div>
		)
	}
}

//The Instructions are updated when: api is hit, when api brings back data, when api returns nothing
class Instructions extends React.Component{
	constructor(props) {
    	super(props);
	    this.state = {
	    };
	}
	render(){
		return(
			<div className="col-12 instructions">
				<h1>React App</h1>
				<h3>{this.props.doThis}</h3>
			</div>
		)
	}
}

class App extends React.Component{
	constructor() {
    	super();
    	this.pullFromApi = this.pullFromApi.bind(this);
	    this.state = {
	    	offset : 0,
	    	characterTotal : 0,
	    	characters: [],
	    	comics: [],
	    	dothis: "Select a letter to show the character list",
	    	"charactersLoading": "",
	    	"comicsLoading": ""
	    };
	}
	pullFromApi(pointer,type,url){
		let curState = this
		//Position of start of each list beginning with letter of the alphabet from the API
							// A  B  C   D   E   F   G   H   I   J   K   L   M   N   O   P   Q   R    S    T     U   V     W    X   Y    Z
		let letterPositions = [0,80,172,272,350,383,420,475,546,584,627,662,716,868,913,933,995,1004,1063,1259,1352,1373,1406,1462,1478,1481]
		let highestLimit = 100
		let calcOffset = letterPositions[pointer]
		let curLimit = 0
		let calcLimit = 0
		let getCharacters = {}
		type == "comic" ? calcLimit = 100 : calcLimit = letterPositions[pointer+1] - calcOffset
		
		pointer !== (letterPositions.length -1) ? calcLimit = letterPositions[pointer+1] - letterPositions[pointer] : calcLimit = highestLimit
		let runAPIhitThisManyTimes = Math.ceil(calcLimit/highestLimit)
		calcLimit > highestLimit ? curLimit = highestLimit : curLimit = calcLimit
		let loading = "Loading... Depending on the size of the list, this may take time."
		if(type == "character"){
			curState.setState({comics: []})
			curState.setState({characters: []})
			curState.setState({comicsLoading: ""})
			curState.setState({charactersLoading: loading})
		}else{
			curState.setState({comics: []})
	 		curState.setState({comicsLoading: loading})
		}
		//you can only retrieve up to 100 items from the api at a time
		//so lists with more than that move the offset and call the left
		//over amounts
		for (let i = 0; i < runAPIhitThisManyTimes; i++) {
			let timestamp = new Date().getTime() / 1000
	 		let hashAll = MD5(timestamp+apiStuff.myPrvKey+apiStuff.myPubKey)
			axios.get(url, {
			    params: {
			      ts: timestamp,
			      apikey: apiStuff.myPubKey,
			      hash: hashAll,
			      offset: calcOffset,
			      limit: curLimit
			    }
			})
			.then(function (response) {
				let newPull = response.data.data.results.map((obj) => obj)
				if(newPull.length == 0){
					newPull = {'no': 'Sorry, there are no '+type+'s under this letter'}
					let selectDiff = 'letter'
					if(type == "comic") selectDiff = "character"
					curState.setState({dothis: "Please select a different "+selectDiff})
					type == "character" ? curState.setState({characters: newPull}) : curState.setState({comics: newPull})
				}else{
					type == "character" ? curState.setState({dothis: "Please select a "+type}) : curState.setState({dothis: "All available comics will be shown when loading is done"})
					type == "character" ? curState.setState({characters: curState.state.characters.concat(newPull)}) : curState.setState({comics: curState.state.comics.concat(newPull)})
				}
				console.log(curState.state.comics)
			})
			.catch(function (error) {
			    console.log(error);
			});
			if(runAPIhitThisManyTimes > 1){
				curLimit = Math.abs(calcLimit - (highestLimit * (i+1)))
				calcOffset = calcOffset + (highestLimit * (i+1))
			}
		}
	}
	render(){
		return(
			<div className="container">
				<div className="row">
					<Instructions doThis={this.state.dothis} />
					<AlphabetList onClick={this.pullFromApi.bind(this)} />
					<CharacterListContainer onClick={this.pullFromApi.bind(this)} selectedCharacters={this.state.characters} comicsLoading={this.state.comicsLoading} charactersLoading={this.state.charactersLoading} />
					<ComicsContainer selectedComics={this.state.comics} comicsLoading={this.state.comicsLoading} />
				</div>
			</div>
		) 
	}
}

render(<App/>, document.getElementById('app'));