
module.exports = {
	myPubKey : "a669e2f3c66891574cf82033c3eef91c",
	myPrvKey : "0c18fe13327e5465fbdf1800bcc18c0cb62f9ad6"
}