<?php
/**
 * Template part for displaying large statistics
 * 1 large image
 * 1 large title
 * optional overlay
 * optional overlay title
 * optional overlay blurb
 *
 * page-home.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Conduent
 */


?>


<?php endif; ?>
