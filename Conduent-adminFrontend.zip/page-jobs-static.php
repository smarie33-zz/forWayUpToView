<?php
/**
* Template Name: Careers Static

* @package Conduent

**/

get_header(); ?>
	<div id="primary" class="content-area careers corporate-page light-gray-bg">
		<main id="main" class="site-main" role="main">
			<section class="cwf-video-header container-fluid">
				<div class="mobile-bg hidden-md hidden-lg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/careers-bg.jpg')">
				</div>
				<video autoplay="" loop="" muted="" class="hidden-xs hidden-sm">
					<source src="<?php bloginfo('template_url') ?>/placeholderdummycontent/careers-video.mp4" type="video/mp4">
					<source src="<?php bloginfo('template_url') ?>/placeholderdummycontent/careers-video.webm" type="video/webm">
				</video>
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-7 col-md-5">
							<h6 class="white-text eyebrow cwf-margin-top-76 cwf-margin-bottom-0">Careers</h6>
							<h1 class="white-text tablet-outlier cwf-margin-top-0">
								Make a difference in the lives of millions.
							</h1>
							<a class="btn btn-lg white transparent blacktext-uppercase" href="https://conduent.taleo.net/careersection/conduent_external_portal/jobsearch.ftl">View All Jobs</a>
						</div>
					</div>
				</div>
			</section>

			<div class="cwf-inverse-arrow">
				<div class="left"></div><div class="right"></div>
			</div>
			
			<section class="main-copy" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/careers_black.svg')">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-4 col-md-3">
							<hr class="cwf-hr call-out">
							<h2 class="white-text">Advancing the Everyday</h2>
							<p class="tablet-outlier white-text">From managing transit systems to promoting new ways to access healthcare, we play a role in the daily lives of people across the globe.</p>
						</div>
						<div class="col-xs-12 col-sm-8 cold-md-9">
							<iframe class="youtube-video" width="710" height="399" src="https://www.youtube.com/embed/e-t4XaROMwk" frameborder="0" allowfullscreen></iframe>
						</div>
					</div>
					<div class="second row">
						<div class="col-xs-12 col-md-offset-4 col-md-8">
							<hr class="cwf-hr call-out">
							<h1 class="white-text">Conduent is more than just the world’s largest business process services company. We’re changing the way businesses and governments interact with their citizens, customers and employees, every single day.</h1>
						</div>
					</div>
					<div class="row">
						<div class="col-xs-12 col-md-offset-4 col-md-8">
							<p class="tablet-outlier white-text">At Conduent, you’ll find unique opportunities to work for some of the world’s biggest brands: accelerating employee training and career development for Hertz, ensuring customers enjoy more quality time on the open ocean with Royal Caribbean, unlocking efficiencies through digital transformation with Procter &amp; Gamble. Thanks to our many talented employees, we’re modernizing the constituent experience—and moving the world forward.</p>
						</div>
					</div>
				</div>
			</section>

			<section class="container-fluid perks">
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-7 left-image">
						<div class="bg" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/green_shape.svg');">
							<div class="image" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-599979274.jpg');"></div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-5 right-text">
						<hr class="cwf-hr call-out">
						<h1>Your health, well-being and family are what matter most.</h1>
						<p>That’s why we offer competitive benefits including paid holidays, healthcare, life insurance, retirement savings and more.</p>
					</div>
				</div>
				<div class="second row">
					<div class="col-xs-12 col-sm-6 col-sm-push-6 right-image">
						<div class="bg" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/darkgreen_shape.svg');">
							<div class="image" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-469617289.jpg');"></div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-sm-pull-6 left-text">
						<hr class="cwf-hr call-out">
						<h1>Join a community of diverse skills and backgrounds.</h1>
						<p>Our employees bring a range of different experiences to the table. In today’s globally connected world, our shared commitments to respect each other and promote equality of opportunity for all people are critical to our success.</p>
					</div>
				</div>
			</section>

			<section class="container-fluid white-bg opportunity">
				<div class="container">
				<div class="row">
					<h1 class="xlarge text-center">Opportunity is Everywhere</h1>
				</div>
				<div class="content row">
					<div class="col-xs-12 col-sm-12 col-md-9">
						<img class="map" src="<?php bloginfo('template_url') ?>/placeholderdummycontent/map_1.svg">
						<img class="map" src="<?php bloginfo('template_url') ?>/placeholderdummycontent/map_2.svg">
						<img class="map" src="<?php bloginfo('template_url') ?>/placeholderdummycontent/map_3.svg">
						<img class="map" src="<?php bloginfo('template_url') ?>/placeholderdummycontent/map_4.svg">
						<svg class="map orangeDots" viewBox="0 0 957 502">
							<defs><style>.cls-1{fill:#ff8700;}</style></defs>
							<circle class="cls-1" cx="484.9" cy="117.4" r="3"/><circle class="cls-1" cx="497.2" cy="123" r="3"/><circle class="cls-1" cx="441.7" cy="123" r="3"/><circle class="cls-1" cx="491" cy="134.1" r="3"/><circle class="cls-1" cx="429.4" cy="156.4" r="3"/><circle class="cls-1" cx="478.7" cy="83.9" r="3"/><circle class="cls-1" cx="521.8" cy="106.2" r="3"/><circle class="cls-1" cx="743.8" cy="256.8" r="3"/><circle class="cls-1" cx="780.8" cy="212.2" r="3"/><circle class="cls-1" cx="281.5" cy="396.2" r="3"/><circle class="cls-1" cx="195.1" cy="262.4" r="3"/><circle class="cls-1" cx="244.5" cy="273.5" r="3"/><circle class="cls-1" cx="324.6" cy="334.9" r="3"/><circle class="cls-1" cx="269.1" cy="362.7" r="3"/><circle class="cls-1" cx="182.8" cy="123" r="3"/><circle class="cls-1" cx="232.2" cy="156.4" r="3"/><circle class="cls-1" cx="152" cy="206.6" r="3"/><circle class="cls-1" cx="201.3" cy="217.8" r="3"/><circle class="cls-1" cx="232.2" cy="223.3" r="3"/><circle class="cls-1" cx="509.5" cy="117.4" r="3"/><circle class="cls-1" cx="472.6" cy="123" r="3"/><circle class="cls-1" cx="441.7" cy="134.1" r="3"/><circle class="cls-1" cx="484.9" cy="162" r="3"/><circle class="cls-1" cx="435.6" cy="111.8" r="3"/><circle class="cls-1" cx="842.45" cy="407.45" r="3"/><circle class="cls-1" cx="768.5" cy="279.1" r="3"/><circle class="cls-1" cx="817.7" cy="167.6" r="3"/><circle class="cls-1" cx="756.1" cy="173.1" r="3"/><circle class="cls-1" cx="663.7" cy="228.9" r="3"/><circle class="cls-1" cx="725.35" cy="240.1" r="3"/>
						</svg>
					</div>
					<div class="col-xs-12 col-sm-8 col-md-3 copy">
						<p class="text-left cwf-padding-bottom-md-0 tablet-outlier">Whether you’re in Mumbai or Manila, San Francisco or Singapore, you’ll have the opportunity to enhance the daily interactions of people across the globe. We invite you to discover your role in advancing the everyday.</p>
						<a class="btn btn-lg transparent black hidden-xs hidden-sm cwf-margin-top-64 text-uppercase" href="https://conduent.taleo.net/careersection/conduent_external_portal/jobsearch.ftl">View All Jobs</a>
					</div>
					<div class="col-xs-12 col-sm-4 text-center hidden-md hidden-lg">
						<a class="btn btn-lg transparent black text-uppercase cwf-margin-top-sm-32 cwf-margin-top-md-0" href="https://conduent.taleo.net/careersection/conduent_external_portal/jobsearch.ftl">View All Jobs</a>
					</div>
				</div>
				</div>
			</section>

			<section class="container bottom-articles">
				<div class="row">
					<div class="col-xs-12 col-md-6 article-container">
						<a class="cwf-article-image-left" href="/about/">
							<div class="image col-xs-6" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-652992811-min.jpg');">
							</div>
							<div class="content col-xs-6">
								<hr class="cwf-hr article">
								<h4 class="title">About Us</h4>
								<p class="hidden-xs">We’re the world’s largest business process services company. See what makes us different than the rest.</p>
								<div class="cta link-blue hidden-xs">Learn more</div>
							</div>
						</a>
					</div>
					<div class="col-xs-12 col-md-6 article-container">
						<a class="cwf-article-image-left" href="/innovation/">
							<div class="image col-xs-6" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-541412737-crop.jpg');">
							</div>
							<div class="content col-xs-6">
								<hr class="cwf-hr article">
								<h4 class="title">Innovation</h4>
								<p class="hidden-xs">Innovation is both a discipline and a mindset. Explore our unique approach to creating new solutions and services.</p>
								<div class="cta link-blue hidden-xs">Learn more</div>
							</div>
						</a>
					</div>
				</div>
			</section>
		</main>
	</div>

<?php
get_footer();
