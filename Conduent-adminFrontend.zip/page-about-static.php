<?php
/**
* Template Name: About Static

* @package Conduent

*/

get_header(); ?>
	<div id="primary" class="content-area about-us corporate-page light-gray-bg">
		<main id="main" class="site-main" role="main">
			<section class="cwf-video-header container-fluid">
				<div class="mobile-bg hidden-md hidden-lg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/about-alt-bg.jpg')">
				</div>
				<video autoplay="" loop="" muted="" class="hidden-xs hidden-sm">
					<source src="<?php bloginfo('template_url') ?>/placeholderdummycontent/about_alt.mp4" type="video/mp4">
					<source src="<?php bloginfo('template_url') ?>/placeholderdummycontent/about_alt.webm" type="video/webm">
				</video>
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-10 col-md-8">
							<h6 class="white-text eyebrow cwf-margin-top-76 cwf-margin-bottom-0">About Us</h6>
							<h1 class="white-text tablet-outlier cwf-margin-top-0">
								Our promise is built on innovation, expertise and the valued partnership of our people. It’s how we deliver on that promise that makes us different.
							</h1>
						</div>
					</div>
				</div>
			</section>

			<div class="cwf-inverse-arrow">
				<div class="left"></div><div class="right"></div>
			</div>
			
			<section class="container conduent-difference">
				<div class="row">
					<div class="col-xs-12 col-sm-offset-4 col-sm-8">
						<hr class="cwf-hr call-out">	
						<h1 class="xlarge">The Conduent<br> Difference</h1>
						<p class="light">
							As the world’s largest multi-service business process services company, we’re changing the way businesses and governments interact with their citizens, customers and employees. Our mission is to modernize the constituent experience by making every interaction digital, personalized and secure. 
						</p>
					</div>
				</div>
			</section>
			
			<section class="container cwf-margin-top-xs-0 cwf-margin-top-sm-32 cwf-margin-top-md-64">
				<div class="row">
					<div class="col-xs-12 col-sm-4 top-border lives cwf-margin-bottom-xs-32">
						We make a difference&nbsp;in the lives of millions every&nbsp;day.
					</div>
					<div class="col-xs-6 col-sm-4 top-border industries">
						<div class="giant-number">18</div>
						industry sectors
					</div>
					<div class="col-xs-6 col-sm-4 top-border countries">
						<div class="giant-number">40+</div>
						countries around the world
					</div>
				</div>
			</section>

			<section class="container frosted-tiles cwf-margin-top-xs-32 cwf-margin-top-sm-48 cwf-margin-top-md-64 cwf-padding-top-md-64">
				<div class="row">
					<div class="col-xs-12 col-sm-4">
						<div class="healthcare tile">
							<div class="tile-bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-607035267-min.jpg')">
							</div>
							<div class="frost">
								<svg>
									<defs>
										<filter id="blur">
											<feGaussianBlur in="SourceGraphic" stdDeviation="10"></feGaussianBlur>
										</filter>
									</defs>
									<image filter="url(#blur)" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-607035267-min.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMidYMax slice"></image>
								</svg>
							</div>
							<div class="labels">
								<h6 class="white-text eyebrow">Healthcare</h6>
								<div class="white-text giant-number">20/20</div>
								<p class="white-text">managed U.S. healthcare plans are clients</p>
							</div>
						</div>
					</div>

					<div class="col-xs-12 col-sm-4">
						<div class="full-image technology tile">
							<div class="tile-bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-586080847-min.jpg')">
							</div>
							<div class="frost">
								<svg>
									<image filter="url(#blur)" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-586080847-min.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMidYMax slice"></image>
								</svg>
							</div>
							<div class="labels">
								<h6 class="white-text eyebrow">Technology</h6>
								<div class="white-text giant-number">4/5</div>
								<p class="white-text">top global phone manufacturers count on our services</p>
							</div>
						</div>
					</div>

					<div class="col-xs-12 col-sm-4">
						<div class="commercial tile">
							<div class="tile-bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-664658999-min.jpg')">
							</div>
							<div class="frost">
								<svg>
									<image filter="url(#blur)" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-664658999-min.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMidYMax slice"></image>
								</svg>
							</div>
							<div class="labels">
								<h6 class="white-text eyebrow">Commercial</h6>
								<div class="white-text giant-number">25<span class="small-cap">M</span></div>
								<p class="white-text">cardholders use our digital payment solutions</p>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section class="container-fluid motto" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/about_background_dark.jpg)">
				<h1 class="white-text text-center">
					Everything we do is in service of the client.
					<br class="hidden-xs hidden-sm">
					Everything we build grows out of their&nbsp;needs.
				</h1>
			</section>

			<section class="container">
				<div class="row">
					<h1 class="xlarge text-center cwf-margin-top-104 cwf-margin-bottom-md-64 cwf-margin-bottom-sm-48 cwf-padding-bottom-md-16">Recognition &amp; Awards</h1>
				</div>
				<div class="row">
					<div class="award col-xs-12 col-sm-6 col-md-4">
						<hr class="cwf-hr call-out">
						<h6 class="eyebrow">Customer Care</h6>
						<span class="award-title">Leader,<br> Customer Management Contact Center&nbsp;BPO</span>
						<p>Gartner</p>
					</div>
					<div class="award col-xs-12 col-sm-6 col-md-4">
						<hr class="cwf-hr call-out">
						<h6 class="eyebrow">Human Resources</h6>
						<span class="award-title">Leader,<br> Health &amp; Wellness&nbsp;BPO</span>
						<p>Nelson Hall</p>
					</div>
					<div class="award col-xs-12 col-sm-6 col-md-4">
						<hr class="cwf-hr call-out">
						<h6 class="eyebrow">Finance and Accounting</h6>
						<span class="award-title">Leader,<br> Finance &amp; Accounting&nbsp;BPO</span>
						<p>IDC</p>
					</div>
					<div class="award col-xs-12 col-sm-6 col-md-4">
						<hr class="cwf-hr call-out">
						<h6 class="eyebrow">Healthcare</h6>
						<span class="award-title">Leader,<br> Health Care Payer&nbsp;BPO</span>
						<p>Everest</p>
					</div>
					<div class="award col-xs-12 col-sm-6 col-md-4">
						<hr class="cwf-hr call-out">
						<h6 class="eyebrow">Public Sector</h6>
						<span class="award-title">Best Partnership Pr., Vehicle Passenger Detection System</span>
						<p>ITS</p>
					</div>
					<div class="award col-xs-12 col-sm-6 col-md-4">
						<hr class="cwf-hr call-out">
						<h6 class="eyebrow">Innovation</h6>
						<span class="award-title">Winner, 2016 Outstanding Corporate Innovator</span>
						<p>PDMA</p>
					</div>
				</div>
			</section>

			<section class="container-fluid innovation half-frost cwf-margin-top-32">
				<div class="row">
					<div class="image col-xs-12 visible-xs-block" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-541412737-mobile.jpg');">
					</div>
					<div class="background col-xs-12 col-sm-6">
						<svg>
							<image filter="url(#blur)" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-541412737-crop2.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMidYMax slice"></image>
						</svg>
					</div>
					<div class="content col-xs-12 col-sm-6">
						<h1 class="white-text cwf-margin-top-0">
							Innovation through <nobr>co-creation.</nobr>
						</h1>
						<p class="white-text">
							Fueled by an innovative mindset and an entrepreneurial culture, we constantly find new ways to create unique value for our clients. Every day we engage in relentless pursuit of greater solutions to improve the lives of citizens, patients and employees around the world.
						</p>
						<a href="/innovation/" class="btn btn-lg transparent white text-uppercase">Learn more</a>
					</div>
					<div class="image col-sm-6 hidden-xs" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-541412737-crop1.jpg');">
					</div>
				</div>
			</section>

			<section class="container cwf-margin-top-xs-32 cwf-margin-top-sm-64">
				<div class="row">
					<h1 class="text-center cwf-margin-bottom-md-64 cwf-margin-bottom-sm-48">In the News</h1>
				</div>
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-4">
						<a class="cwf-article-title-under" href="#">
							<div class="image" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-547016271.jpg);">
							</div>
							<div class="content">
								<hr class="cwf-hr article">
								<h2 class="title">Consumer Challenges ahead of Open Enrollment Period</h2>
								<p>Healthcare expertise can help insurers win the &ldquo;undecided vote&rdquo; this season</p>
								<div class="cta link-blue">Read more</div>
							</div>
						</a>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4">
						<a class="cwf-article-title-under" href="#">
							<div class="image" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-626778706.jpg);">
							</div>
							<div class="content">
								<hr class="cwf-hr article">
								<h2 class="title">High Expectations for Transportation Innovation</h2>
								<p>Conduent releases early results from its Global Transportation Survey at ITS World Congress</p>
								<div class="cta link-blue">Read more</div>
							</div>
						</a>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 hidden-xs hidden-sm">
						<a class="cwf-article-title-under" href="#">
							<div class="image" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-664647961.jpg);">
							</div>
							<div class="content">
								<hr class="cwf-hr article">
								<h2 class="title">Recognized for Innovative Legal Analytics Platform</h2>
								<p>The Analytics Hub reduces costs up to 60 percent</p>
								<div class="cta link-blue">Read more</div>
							</div>
						</a>
					</div>
				</div>
			</section>

			<div class="text-center">
				<a class="btn btn-lg transparent black text-uppercase see-news-btn" href="https://www.news.conduent.com/">See latest news</a>
			</div>

			<section class="container-fluid headquarters">
				<div class="row">
					<div class="image" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/logo_signwall_mockup-min.jpg)">
					</div>
					<div class="content">
						<h2 class="title">Corporate Headquarters</h2>
						<p>233 Mount Airy Rd.<br>
						Suite 100<br>
						Basking Ridge, NJ 07920</p>
						<p class="cwf-padding-bottom-sm-32">
							<a target="_blank" href="https://www.google.com/maps/place/233+Mt+Airy+Rd,+Basking+Ridge,+NJ+07920">MAP</a>
						</p>
					</div>
				</div>
			</section>

			<section class="container bottom-articles">
				<div class="row">
					<div class="col-xs-12 col-md-6 article-container">
						<a class="cwf-article-image-left" href="/leadership/">
							<div class="image col-xs-6" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/Ashok_Vemuri_sm.jpg');">
							</div>
							<div class="content col-xs-6">
								<hr class="cwf-hr article">
								<h4 class="title">Leadership</h4>
								<p class="hidden-xs">Our leaders put service at the center of our business. Meet the team that’s driving us forward.</p>
								<div class="cta link-blue hidden-xs">Learn more</div>
							</div>
						</a>
					</div>
					<div class="col-xs-12 col-md-6 article-container">
						<a class="cwf-article-image-left" href="/jobs/">
							<div class="image col-xs-6" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-530682631-crop.jpg');">
							</div>
							<div class="content col-xs-6">
								<hr class="cwf-hr article">
								<h4 class="title">Careers</h4>
								<p class="hidden-xs">We foster a culture where the best idea wins. Learn more about opportunities at Conduent.</p>
								<div class="cta link-blue hidden-xs">Learn more</div>
							</div>
						</a>
					</div>
				</div>
			</section>
		</main>
	</div>

<?php
get_footer();
