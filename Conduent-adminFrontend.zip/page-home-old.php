<?php
/*
Template Name: Home Page Static
*/

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
		
			<section class="cwf-large-image-header container-fluid">
				<div class="image" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/GettyImages-181891493-1024x682.jpg)"></div>
				<div class="darken-image"></div>
				<div class="container">
					<div class="row">
						<div class="col-md-8 col-sm-8">
							<h1 class="white-text tablet-outlier">Changing how businesses and governments interact with citizens, customers and employees.</h1>
							<button class="btn btn-lg transparent white" href="#">LEARN MORE</button>
						</div>
					</div>
				</div>

			</section>
			<div class="cwf-inverse-arrow container-fluid">
				<div class="row">
					<div class="left"></div><div class="right"></div>
				</div>
			</div>
			<section class="container-fluid light-gray-bg cwf-padding-top-xs-32 cwf-padding-bottom-xs-64 cwf-padding-top-sm-16 cwf-padding-bottom-sm-48 cwf-padding-bottom-md-64 cwf-stat-callout">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<hr class="cwf-hr call-out">							
						</div>
						<div class="col-md-3 col-sm-5">
							<h2 class="tablet-outlier">Serving millions of people every day</h2>
						</div>
						<div class="col-md-8 col-md-offset-1 col-sm-12">
							<p class="xs-small tablet-outlier light cwf-margin-bottom-0 cwf-margin-top-0 cwf-padding-bottom-0">
								Today’s constituent interactions must be digital, personalized and secure. We work with our clients to co-develop solutions that not only meet these criteria, but improve the loyalty and satisfaction of those we serve.
							</p>
							<div class="cwf-padding-top-32">
								<a class="btn btn-lg transparent black-text" href="https://test.colorsticks.com/services/"><strong>VIEW ALL SERVICES</strong></a>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section class="container-fluid light-gray-bg cwf-padding-bottom-24">
				<div class="container">
					<div class="row">
						<div id="masonry">
							<div class="col-md-8">
								<a href="https://test.colorsticks.com/services/healthcare-solutions/" class="cwf-masonry-block black-bg" style="background-image: url(<?php bloginfo('template_url'); ?>/placeholderdummycontent/T01_m310_531469140.jpg)">
									<div class="for-mobile visible-xs-block" style="background-image: url(<?php bloginfo('template_url'); ?>/placeholderdummycontent/T01_m310_531469140.jpg)"></div>
									<div class="box-frost">
										<div class="frost-gradient"></div>
										<div class="frost-this">
											<svg>
											    <defs>
											      <filter id="blur">
											        <feGaussianBlur in="SourceGraphic" stdDeviation="10" />
											      </filter>
											    </defs>
											    <image filter="url(#blur)" xlink:href="<?php bloginfo('template_url'); ?>/placeholderdummycontent/T01_m310_531469140.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMinYMin slice" />
											 </svg>
										</div>
									</div>
									<div class="unfrosted-content">
										<div class="col-sm-6"></div>
										<div class="col-sm-6 frost">
											<div class="eyebrow text-uppercase white-text">Health</div>
											<div class="large-number white-text">67<sup>%</sup></div>
											<p class="white-text light">of all U.S. insured patients receive our scalable and flexible healthcare solutions</p>
											<div class="cta dock dark-bg hidden-xs">Learn more about health</div>
											<div class="cta dark-bg visible-xs-block">Learn more</div>
											<div class="clear-fix"></div>
										</div>
									</div>
								</a>
							</div>

							<div class="col-md-4">
								<div class="cwf-masonry-block teal social">
									<div class="col-md-12 col-sm-6 col-xs-12">
										<div class="eyebrow text-uppercase white-text">Follow</div>
										<h2 class="cwf-padding-top-32 cwf-margin-bottom-0 white-text tablet-outlier">Connect with us on<br> social media</h2>
									</div>
									<div class="col-md-12 col-sm-6 col-xs-12 cwf-padding-left-0 cwf-padding-right-0 vertical-center">
										<div class="col-xs-3">
											<a class="social" href="#">
											<h2 class="large white-text text-left i-cwf-fb-icon"></h2>
											</a>
										</div>
										<div class="col-xs-3">
											<a class="social" href="#">
												<h2 class="large white-text text-center i-cwf-twitter-icon"></h2>
											</a>
										</div>
										<div class="col-xs-3">
											<a class="social" href="#">
												<h2 class="large white-text text-center i-cwf-linkedin-icon"></h2>
											</a>
										</div>
										<div class="col-xs-3">
											<a class="social video" href="#">
												<h2 class="large white-text text-right i-cwf-youtube-icon"></h2>
											</a>
										</div>
										<div class="clearfix"></div>
									</div>
									<div class="clearfix"></div>
								</div>								
							</div>

							<div class="col-md-4">
								<a class="cwf-masonry-block long black-bg" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/T01_m310_582313456.jpg)">
									<div class="for-mobile visible-xs-block" style="background-image: url(<?php bloginfo('template_url'); ?>/placeholderdummycontent/T01_m310_582313456-crop.jpg)"></div>
									<div class="box-frost">
										<div class="frost-gradient"></div>
										<div class="frost-this">
											<svg>
											    <defs>
											      <filter id="blur">
											        <feGaussianBlur in="SourceGraphic" stdDeviation="10"></feGaussianBlur>
											      </filter>
											    </defs>
											    <image filter="url(#blur)" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="<?php bloginfo('template_url'); ?>/placeholderdummycontent/T01_m310_582313456.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMinYMin slice"></image>
											 </svg>
										</div>
									</div>
									<div class="unfrosted-content">
										<div class="visible-sm-block col-sm-6"></div>
										<div class="col-md-12 col-sm-6 frost">
											<div class="eyebrow text-uppercase white-text">CUSTOMER CARE</div>
											<div class="large-number white-text">3/5</div>
											<p class="white-text light">of the top 5 U.S. mobile phone providers offer Conduent support and services</p>
											<div class="cta dock dark-bg hidden-xs">Learn more about Customer Care</div>
											<div class="cta dark-bg visible-xs-block">Learn more</div>
										</div>
									</div>
								</a>
							</div>

							<div class="col-md-8">
								<a class="cwf-masonry-block col-md-12 white-bg right-image">
									<div class="col-md-12 full-height">
										<div class="col-sm-7 col-xs-12">
											<div class="eyebrow dark-gray-text text-uppercase">FINANCE &amp; ACCOUNTING INSIGHTS</div>
											<hr class="cwf-hr article">
											<h4 class="title">Millenials’ Income</h4>
											<p class="light">Millennials have money on their minds. Now the largest demographic group in the workforce, Millennials have a different view of their income compared to Gen Xers and... </p>
										</div>
										<div class="col-sm-4 col-sm-offset-1 full-height hidden-xs" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/T01_m310_165919068.jpg)"></div>
									</div>
									<div class="cta dock">Read more</div>
								</a> 

								<a class="cwf-masonry-block col-md-12 black-bg wide" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/T01_m310_147541629.jpg)">
									<div class="for-mobile visible-xs-block" style="background-image: url(<?php bloginfo('template_url'); ?>/placeholderdummycontent/T01_m310_147541629.jpg)"></div>
									<div class="box-frost">
										<div class="frost-gradient"></div>
										<div class="frost-this">
											<svg>
											    <defs>
											      <filter id="blur">
											        <feGaussianBlur in="SourceGraphic" stdDeviation="10" />
											      </filter>
											    </defs>
											    <image filter="url(#blur)" xlink:href="<?php bloginfo('template_url') ?>/placeholderdummycontent/T01_m310_147541629.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMinYMin slice" />
											 </svg>
										</div>
									</div>
									<div class="unfrosted-content">
										<div class="col-sm-5 frost">
											<div class="eyebrow text-uppercase white-text">TRANSPORTATION</div>
											<div class="large-number white-text">9M</div>
											<p class="white-text light">daily travelers use Conduent-managed toll systems</p>
											<div class="cta dock dark-bg hidden-xs">Learn more about Transportation</div>
											<div class="cta dark-bg visible-xs-block">Learn more</div>
										</div>
									</div>
								</a>
							</div>

							<div class="clearfix"></div>

							<div class="col-md-8">
								<a href="" class="cwf-masonry-block white-bg col-md-12 left-image">
									<div class="col-sm-4 hidden-xs full-height" style="background-image: url(https://cduwp.wpengine.com/wp-content/uploads/2016/10/vector1_gray_teal_lg.svg); background-position: right bottom;"></div>
									<div class="col-md-8 col-sm-8 col-xs-12 full-height">
										<div class="eyebrow dark-gray-text text-uppercase">HUMAN RESOURCES INSIGHTS</div>
										<hr class="cwf-hr article">
										<h4 class="title">Planning the HR of the Future</h4>
										<p>With low Canadian bond yields, some institutional investors are wondering about their asset allocation strategy and how they can better manage their portfolio to increase the yield and…</p>
										<div class="cta dock hidden-xs">Read more</div>
									</div>
									<div class="cta cwf-padding-left-24 dock visible-xs-block">Read more</div>
								</a>

								<div class="col-md-6 no-tablet-padding">
									<a href="" class="cwf-masonry-block white-bg right-image">
										<div class="col-md-12 col-sm-8 col-xs-12 full-height">
											<div class="eyebrow dark-gray-text text-uppercase">LEGAL &amp; COMPLIANCE INSIGHTS</div>
											<hr class="cwf-hr article">
											<h4 class="title">Upgrading Cybersecurity</h4>
											<p>9 steps to passing the SEC’s cybersecurity test.</p>
											<div class="cta dock cwf-padding-left-0 hidden-xs">Read more</div>
										</div>
										<div class="cta dock cwf-padding-left-0 visible-xs-block">Read more</div>
										
										<div class="col-sm-4 visible-sm-block full-height" style="background-image: url(https://cduwp.wpengine.com/wp-content/uploads/2016/10/vector3_gray_teal_lg.svg); background-position: right bottom;"></div>
									</a>
								</div>

								<div class="col-md-6 no-tablet-padding">
									<a class="cwf-masonry-block dark-teal facebook" href="http://xerox.bz/2dhs9Ou">
										<h3 class="social-icon white-text i-cwf-fb-icon"></h3>
										<p class="white-text col-md-12 col-md-offset-0 col-sm-8 col-sm-offset-2 cwf-padding-left-0"><strong>Our CMO John Kennedy</strong> explains how the Conduent logo came to be.</p>
										<p class="white-text col-md-12 col-md-offset-0 col-sm-10 col-sm-offset-2 cwf-padding-left-0">http://xerox.bz/2dhs9Ou</p>	
									</a>
								</div>
							</div>

							<div class="col-md-4">
								<a href="" class="cwf-masonry-block long black-bg quote" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/T01_m310_645425521.jpg)">
									<div class="box-frost">
										<div class="frost-gradient"></div>
										<div class="frost-this">
											<svg>
											    <defs>
											      <filter id="blur">
											        <feGaussianBlur in="SourceGraphic" stdDeviation="10"></feGaussianBlur>
											      </filter>
											    </defs>
											    <image filter="url(#blur)" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="<?php bloginfo('template_url') ?>/placeholderdummycontent/T01_m310_645425521.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMinYMin slice"></image>
											 </svg>
										</div>
									</div>
									<div class="unfrosted-content">
										<div class="col-md-12 col-sm-6"></div>
										<div class="col-md-12 col-sm-6 frost">
											<div class="quote-text">
												<div class="social-icon teal-text text-left i-cwf-quote-start-icon"></div>
												<h2 class="white-text tablet-outlier text-left ">At our best, we are making a difference every day in the lives of those we touch.</h2>
												<div class="social-icon teal-text text-right i-cwf-quote-end-icon"></div>
											</div>
											<div class="col-md-12 col-sm-12 col-xs-12 dock">
												<p class="white-text text-right">Ashok Vemuri,<br>CEO of Conduent</p>
											</div>
										</div>
									</div>
								</a>
							</div>
						</div>

						<div class="col-md-12 center cwf-padding-top-48">
							<a class="btn btn-lg transparent black-text" href="https://test.colorsticks.com/insights/"><strong>VIEW ALL INSIGHTS</strong></a>
						</div>
						<div class="col-md-12 cwf-padding-bottom-24 hidden-xs hidden-sm"></div>
					</div>
				</div>
			</section>

			<section class="container-fluid cwf-banner homepage black-bg hidden-sm">
				<div class="container black-bg">
					<div class="row">
						<div class="col-md-9 cwf-padding-top-48 cwf-padding-bottom-48">
							<p class="h2 white-text">
								We are experts and innovators, well-versed in technical and regulatory knowledge. We work with our clients to develop secure, scalable and compliant solutions for the contemporary marketplace.
							</p>
						</div>
						<div class="col-md-3 cwf-padding-top-sm-48 cwf-padding-top-xs-0 cwf-padding-bottom-48">
								<h6 class="text-uppercase white-text text-center">Connect with an expert</h6>
								<button href="#" type="button" class="btn btn-teal-border btn-full btn-block text-uppercase">	<sub class="i-cwf-customer-service-icon"></sub><span>1-877-414-2676</span>
								</button>
								<button href="#" type="button" class="btn btn-teal-border btn-full btn-block text-uppercase">	<sub class="i-cwf-form-icon"></sub><span>Contact online</span>
								</button>
								<?php //echo apply_filters( 'the_content','[marketo_form form_id="1099" trigger_selector=".btn-teal-border" trigger_type="custom" title="Cras ultricies ligula sed magna dictum porta" intro="Donec rutrum congue leo eget malesuada. Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur aliquet quam id dui posuere blandit." thankyou="Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Pellentesque in ipsum id orci porta dapibus. "]'); ?>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section class="container-fluid dark-gray-bg cwf-section-padding cwf-link-list">
				<div class="container">
					<div class="row">
						<div class="col-sm-12">
							<h2 class="white-text cwf-margin-bottom-16">Services</h2>
							<hr class="white hidden-xs">

							<div class="dropdown visible-xs-block">
								<button class="btn btn-default btn-full dropdown-toggle btn-med-gray" type="button" id="dropdownMenuService" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false ">
								    Explore our services
									<span class="caret"></span>
								</button>
								<ul class="dropdown-menu" aria-labelledby="dropdownMenuService">
								    <li><a href="#">Customer Care</a></li>
									<li><a href="#">Digital Payments</a></li>
									<li><a href="#">Digital Transformation</a></li>
									<li><a href="#">Finance and Accounting</a></li>
									<li><a href="#">Health</a></li>
									<li><a href="#">Human Resources</a></li>
									<li><a href="#">Learning Services</a></li>
									<li><a href="#">Legal &amp; Compliance Solutions</a></li>
									<li><a href="#">Procurement Solutions</a></li>
									<li><a href="#">Public Sector</a></li>
									<li><a href="#">Workers Compensation</a></li>
									<li><a href="#">All Services</a></li>
								</ul>
							</div>

						</div>
						<div class="col-sm-4 hidden-xs">
							<a href="#"><h4 class="white-text">Customer Care</h4></a>
							<a href="#"><h4 class="white-text">Digital Payments</h4></a>
							<a href="#"><h4 class="white-text">Digital Transformation</h4></a>
							<a href="#"><h4 class="white-text">Finance and Accounting</h4></a>
						</div>
						<div class="col-sm-4 hidden-xs">
							<a href="#"><h4 class="white-text">Health</h4></a>
							<a href="#"><h4 class="white-text">Human Resources</h4></a>
							<a href="#"><h4 class="white-text">Learning Services</h4></a>
							<a href="#"><h4 class="white-text">Legal &amp; Compliance Solutions</h4></a>
						</div>
						<div class="col-sm-4 hidden-xs">
							<a href="#"><h4 class="white-text">Procurement Solutions</h4></a>
							<a href="#"><h4 class="white-text">Public Sector</h4></a>
							<a href="#"><h4 class="white-text">Workers Compensation</h4></a>
							<a href="" class="cwf-small-callout white-text">All Services</a>
						</div>

						<div class="col-sm-12 cwf-padding-top-xs-32 cwf-padding-top-sm-48 cwf-padding-top-md-48">
							<h2 class="white-text cwf-margin-bottom-16">Industries</h2>
							<hr class="white hidden-xs">

							<div class="dropdown visible-xs-block">
								<button class="btn btn-default btn-full dropdown-toggle btn-med-gray text-left" type="button" id="dropdownMenuIndustries" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false ">
								    Explore our industries
									<span class="caret"></span>
								</button>
								<ul class="dropdown-menu" aria-labelledby="dropdownMenuIndustries">
								    <li><a href="#">Categories 1</a></li>
								    <li><a href="#">Categories 2</a></li>
								    <li><a href="#">Categories 3</a></li>
								    <li><a href="#">Categories 4</a></li>
								    <li><a href="#">Categories 5</a></li>
								</ul>
							</div>
						</div>

						<div class="col-sm-4 hidden-xs">
							<a href="#"><h4 class="white-text">Auto, Aerospace and Defense</h4></a>
							<a href="#"><h4 class="white-text">Banking and Capital Markets</h4></a>
							<a href="#"><h4 class="white-text">Communications and Media</h4></a>
							<a href="#"><h4 class="white-text">Health</h4></a>
						</div>
						<div class="col-sm-4 hidden-xs">
							<a href="#"><h4 class="white-text">High Tech</h4></a>
							<a href="#"><h4 class="white-text">Industrials and Energy</h4></a>
							<a href="#"><h4 class="white-text">Insurance</h4></a>
							<a href="#"><h4 class="white-text">Public Sector</h4></a>
						</div>
						<div class="col-sm-4 hidden-xs">
							<a href="#"><h4 class="white-text">Retail and Consumer</h4></a>
							<a href="#"><h4 class="white-text">Transportation</h4></a>
							<a href="#"><h4 class="white-text">Travel and Hospitality</h4></a>
							<a href="" class="cwf-small-callout white-text">All Industries</a>
						</div>
					</div>
					<hr class="white hidden-xs last cwf-margin-top-sm-80 cwf-margin-top-md-104">
				</div>
			</section>

			<?php
			// while ( have_posts() ) : the_post();
			// 	if( function_exists('have_rows')):
				
			// 		//get_template_part( 'template-parts/large-image-header', 'page' );
			// 		//get_template_part( 'template-parts/large-stats', 'page' );
			// 		//get_template_part( 'template-parts/banner', 'page' );
			// 		//get_template_part( 'template-parts/post-list', 'page' );

					
			// 	endif; //end if function_exists

			// endwhile; // End of the loop.
			?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
