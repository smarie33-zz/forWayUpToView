<?php
/*
* Template Name: Innovation Static

* @package Conduent

**/

get_header(); ?>
	<div id="primary" class="content-area innovation corporate-page light-gray-bg">
		<main id="main" class="site-main" role="main">
			<section class="cwf-large-image-header container-fluid">
				<svg class="shape hidden-xs" width="3001" height="660" viewBox="0 0 3001.43 659.83">
					<defs>
						<style>.cls-1{opacity:0.6;}</style>
					</defs>
					<path class="cls-1" d="M-1233.36-962.92l3001.43-.17L1411.9-303.44l-2645.26.17Z" transform="translate(1233.36 963.1)"/>
				</svg>
				<div class="image" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-541412737-min-crop.jpg)"></div>
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-8 col-md-7 content">
							<h6 class="white-text eyebrow cwf-margin-top-76 cwf-margin-bottom-0">Innovation</h6>
							<h1 class="white-text tablet-outlier cwf-margin-top-0">
								At Conduent, we celebrate new ideas and turn them into unique customer value. Our drive for innovation improves the lives of citizens, patients and employees around the world.
							</h1>
						</div>
					</div>
				</div>
			</section>

			<div class="cwf-inverse-arrow">
				<div class="left"></div><div class="right"></div>
			</div>

			<div class="white-bg">
			<section class="container technology-driven">
				<div class="row">
					<div class="col-xs-12 col-sm-offset-1 col-sm-10 col-md-offset-2 col-md-8">
						<hr class="cwf-hr call-out">
						<h1 class="xlarge text-center">
							Technology-driven.<br>
							Customer-centric.
						</h1>
						<p class="light text-center">
							We combine deep user insights and best-in-class technologies to create impactful innovation. And through a co-innovation process, our customers become key partners in creating, developing and testing new, unique solutions.
						</p>
					</div>
				</div>
			</section>
			
			<section class="container frosted-tiles cwf-margin-top-xs-16 cwf-margin-top-md-48">
				<div class="row">
					<div class="col-xs-12 col-sm-4">
						<div class="full-image automation tile">
							<div class="tile-bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-527045000-min.jpg')">
							</div>
							<div class="frost">
								<svg>
									<defs>
										<filter id="blur">
											<feGaussianBlur in="SourceGraphic" stdDeviation="10"></feGaussianBlur>
										</filter>
									</defs>
									<image filter="url(#blur)" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-527045000-min.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMidYMax slice"></image>
								</svg>
							</div>
							<div class="labels">
								<h1 class="white-text">Automation</h1>
								<p class="white-text">We’re experts at creating simple, touch-less business processes to increase productivity, consistency and quality of service.</p>
							</div>
						</div>
					</div>

					<div class="col-xs-12 col-sm-4">
						<div class="analytics tile">
							<div class="tile-bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-579764764-min.jpg')">
							</div>
							<div class="frost">
								<svg>
									<image filter="url(#blur)" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-579764764-min.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMidYMax slice"></image>
								</svg>
							</div>
							<div class="labels">
								<h1 class="white-text">Analytics</h1>
								<p class="white-text">Our analytical capabilities transform big data into useful information to identify operational improvements and constituent insights.</p>
							</div>
						</div>
					</div>

					<div class="col-xs-12 col-sm-4">
						<div class="full-image personalization tile">
							<div class="tile-bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-578192071-min.jpg')">
							</div>
							<div class="frost">
								<svg>
									<image filter="url(#blur)" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-578192071-min.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMidYMax slice"></image>
								</svg>
							</div>
							<div class="labels">
								<h1 class="white-text">Personalization</h1>
								<p class="white-text">Customers want real-time, secure, context-aware services. Our ability to personalize service makes every customer <nobr>touch-point</nobr> count.</p>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section class="container-fluid focus-areas">
				<div class="row">
					<div class="col-xs-12 col-sm-offset-1 col-sm-10 col-md-offset-2 col-md-8">
						<h1 class="xlarge text-center">Our Focus Areas</h1>
						<p class="light text-center">
							Our innovations simplify and improve business processes, driving the rise of truly digital enterprises. We seamlessly integrate automation, analytics and personalization to provide unique capabilities for our customers in multiple industries.
						</p>
					</div>
				</div>
				<div class="row">
					<div class="focus-section transportation">
						<div class="col-xs-12 col-sm-6 image">
							<div class="bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-496097586_retouched-min.jpg')"></div>
						</div>
						<div class="col-xs-12 col-sm-6 content">
							<hr class="cwf-hr call-out">
							<h1>Transportation</h1>
							<p>From advanced passenger and license plate recognition to apps for personalized multi-modal urban travel, our solutions are helping to create a more efficient and livable world.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="focus-section healthcare">
						<div class="col-xs-12 col-sm-7 col-sm-push-5 image">
							<div class="bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-183274276_retouched-min.jpg')"></div>
						</div>
						<div class="col-xs-12 col-sm-5 col-sm-pull-7 content">
							<hr class="cwf-hr call-out">
							<h1>Healthcare</h1>
							<p>We offer integrated data-driven solutions to optimize patient care, drive better outcomes for targeted populations and use the power of analytics to eliminate fraud, waste and abuse.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="focus-section customer-care">
						<div class="col-xs-12 col-sm-6 image">
							<div class="bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-486823254_screenadded-min.jpg')"></div>
						</div>
						<div class="col-xs-12 col-sm-6 content">
							<hr class="cwf-hr call-out">
							<h1>Customer Care</h1>
							<p>Our solutions transform traditional care into an automated multi-channel customer experience. Our sophisticated machine learning-based virtual agents can support human operators and provide self-service.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="focus-section robotics">
						<div class="col-xs-12 col-sm-7 col-sm-push-5 image">
							<div class="bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-532097557_retouched.jpg')"></div>
						</div>
						<div class="col-xs-12 col-sm-5 col-sm-pull-7 content">
							<hr class="cwf-hr call-out">
							<h1><nobr>Robotic Process</nobr><br> Automation</h1>
							<p>Our Automation Suite, which includes proprietary Robotic Process Automation Tools, improves speech, accuracy, quality and regulatory compliance by using software bots to perform routine manual tasks.</p>
						</div>
					</div>
				</div>
			</section>

			<section class="container-fluid track-record cwf-padding-bottom-64">
				<div class="row">
					<h1 class="xlarge text-center cwf-margin-top-xs-64 cwf-margin-top-md-0">A Proven Track Record</h1>
				</div>
				<div class="row cwf-margin-top-xs-16 cwf-margin-sm-32 cwf-margin-top-md-64">
					<div class="col-xs-12 col-sm-5 left-col">
						<div class="bg" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/green_shape.svg')">
							<div class="image" style="background-image: url('<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/PDMA.jpg')">
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-7 right-col">
						<h1 class="cwf-margin-top-0 cwf-margin-bottom-16">Conduent innovation recognized for turning good ideas into customer advantages.</h1>
						<p>Named outstanding corporate innovator by Product Development and Management Association</p>
						<p>
							<a class="cta" href="#">Read more</a>
						</p>
						<div class="row cwf-margin-top-16 hidden-sm">
							<div class="col-sm-6">
								<hr class="cwf-hr call-out">
								<div class="giant-number">600+</div>
								<span class="legend"><nobr>US Patents and Pending</nobr><br> Patent Applications</span>
							</div>
							<div class="col-sm-6 cwf-margin-top-xs-32 cwf-margin-top-sm-0">
								<hr class="cwf-hr call-out">
								<div class="giant-number">240+</div>
								<span class="legend">trademarks</span>
							</div>
						</div>
					</div>
				</div>
				<div class="row visible-sm-block cwf-margin-top-64">
					<div class="col-sm-offset-3 col-sm-3">
						<hr class="cwf-hr call-out">
						<div class="giant-number">600+</div>
						<span class="legend"><nobr>US Patents and Pending</nobr><br> Patent Applications</span>
					</div>
					<div class="col-sm-3">
						<hr class="cwf-hr call-out">
						<div class="giant-number">240+</div>
						<span class="legend">trademarks</span>
					</div>
				</div>
			</section>
			</div>

			<section class="container cwf-margin-top-xs-32 cwf-margin-top-sm-64">
				<div class="row">
					<h1 class="text-center cwf-margin-bottom-md-64 cwf-margin-bottom-sm-48">Innovation Highlights</h1>
				</div>
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-4">
						<a class="cwf-article-title-under" href="#">
							<div class="image" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-494085134.jpg)">
							</div>
							<div class="content">
								<hr class="cwf-hr article">
								<h2 class="title">Leading the Healthcare Revolution</h2>
								<p>We take a different approach to population health outcomes—and it’s proven to work.</p>
								<div class="cta link-blue">Read more</div>
							</div>
						</a>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4">
						<a class="cwf-article-title-under" href="#">
							<div class="image" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-515473470.jpg)">
							</div>
							<div class="content">
								<hr class="cwf-hr article">
								<h2 class="title">Commute Smarter in Los Angeles</h2>
								<p>Our trip planning app gives you the best commute based on time, traffic and other factors.</p>
								<div class="cta link-blue">Read more</div>
							</div>
						</a>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 hidden-xs hidden-sm">
						<a class="cwf-article-title-under" href="#">
							<div class="image" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-629201600.jpg)">
							</div>
							<div class="content">
								<hr class="cwf-hr article">
								<h2 class="title">Better Automation Makes Better Work</h2>
								<p>Process automation may help your day feel less repetitive.</p>
								<div class="cta link-blue">Read more</div>
							</div>
						</a>
					</div>
				</div>
			</section>

			<div class="text-center">
				<a class="btn btn-lg transparent black text-uppercase see-news-btn" href="https://www.news.conduent.com/">See latest news</a>
			</div>

			<section class="conduent-labs">
				<div class="left-col">
					<div class="lab" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-531617035_retouched-min.jpg)">
						<div class="lab-info">
							<h2>Conduent Labs U.S.</h2>
							<p>For more than 50 years, the innovations developed at the New York research center have contributed to some of our most successful products and services.</p>
							<a href="#">Learn more</a>
						</div>
					</div>
				</div><div class="right-col">				
					<div class="lab" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-509919069_retouched-min.jpg)">
						<div class="lab-info">
							<h2>Conduent Labs India</h2>
							<p>Initiated in January 2009, Conduent Labs’ India charter is to explore, develop and incubate innovative services for our global customers, with a special focus on emerging markets.</p>
							<a href="#">Learn more</a>
						</div>
						</div>
				</div>
			</section>

			<section class="container bottom-articles">
				<div class="row">
					<div class="col-xs-12 col-md-6 article-container">
						<a class="cwf-article-image-left" href="/about/">
							<div class="image col-xs-6" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-652992811-min.jpg');">
							</div>
							<div class="content col-xs-6">
								<hr class="cwf-hr article">
								<h4 class="title">About Us</h4>
								<p class="hidden-xs">We’re the world’s largest business process services company. See what makes us different than the rest.</p>
								<div class="cta link-blue hidden-xs">Learn more</div>
							</div>
						</a>
					</div>
					<div class="col-xs-12 col-md-6 article-container">
						<a class="cwf-article-image-left" href="/jobs/">
							<div class="image col-xs-6" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-530682631-crop.jpg');">
							</div>
							<div class="content col-xs-6">
								<hr class="cwf-hr article">
								<h4 class="title">Careers</h4>
								<p class="hidden-xs">We foster a culture where the best idea wins. Learn more about opportunities at Conduent.</p>
								<div class="cta link-blue hidden-xs">Learn more</div>
							</div>
						</a>
					</div>
				</div>
			</section>
		</main>
	</div>

<?php
get_footer();
