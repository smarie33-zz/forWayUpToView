<?php
/*
Template Name: Leadership Static
*/

get_header(); ?>
	<div id="primary" class="content-area leadership corporate-page light-gray-bg">
		<main id="main" class="site-main" role="main">
			<section class="cwf-large-image-header container-fluid">
				<div class="image" style="background-image: url(<?php bloginfo('template_url') ?>/placeholderdummycontent/background_black_01.svg)"></div>
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-10 col-md-9">
							<h6 class="white-text eyebrow cwf-margin-top-76 cwf-margin-bottom-0">Leadership</h6>
							<h1 class="white-text title tablet-outlier">
								We are experts and innovators, combining our collective experience and knowledge to push for the solutions our clients need today.
							</h1>
							<p class="white-text tablet-outlier">
								Through an unwavering focus on our client’s needs, we affect change for millions of people, every single day. We not only understand the complexities of our clients’ industries, we design solutions that help transform their businesses and operate for them on their behalf. 
							</p>
						</div>
					</div>
				</div>
			</section>

			<section class="container leaders">
				<div class="row">
					<div class="col-sm-6 col-xs-12">
						<a href="#" class="leader" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/Ashok-Vemuri-2016-1200px.jpg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Ashok Vemuri</h2>
								<span class="title white-text">Chief Executive Officer</span>
							</div>
						</a>
					</div>
					<div class="col-sm-6 col-xs-12">
						<a href="#" class="leader" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/vector3_teal_lg.svg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Brian Webb-Walsh</h2>
								<span class="title white-text">Chief Financial Officer</span>
							</div>
						</a>
					</div>
					<div class="col-sm-6 col-xs-12">
						<a href="#" class="leader" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/vector3_teal_lg.svg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Jay Chu</h2>
								<span class="title white-text">Chief Accounting Officer</span>
							</div>
						</a>
					</div>
					<div class="col-sm-6 col-xs-12">
						<a href="#" class="leader" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/vector3_teal_lg.svg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Frederick S. Koury</h2>
								<span class="title white-text">Chief Human Resources Officer</span>
							</div>
						</a>
					</div>
					<div class="col-sm-6 col-xs-12">
						<a href="#" class="leader" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/161201_Mike_Peffer__001.jpg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">James Michael Peffer</h2>
								<span class="title white-text">General Counsel and Secretary</span>
							</div>
						</a>
					</div>
					<div class="col-sm-6 col-xs-12">
						<a href="#" class="leader" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/161201_Dave_Amorieli_003.jpg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Dave Amoriell</h2>
								<span class="title white-text">President, Public Sector</span>
							</div>
						</a>
					</div>
					<div class="col-sm-6 col-xs-12">
						<a href="#" class="leader" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/161201_Carol_Kline__004_copy.jpg?foo=bar');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Carol Kline</h2>
								<span class="title white-text">Chief Information Officer</span>
							</div>
						</a>
					</div>
				</div>
			</section>

			<section class="container directors">
				<div class="row">
					<h1 class="text-center cwf-margin-top-sm-64 cwf-margin-top-xs-48 cwf-margin-bottom-md-64 cwf-margin-bottom-xs-32">Board of Directors</h1>
				</div>
				<div class="row">
					<div class="col-md-4 col-sm-6 col-xs-12">
						<a href="#" class="director" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/Ashok-Vemuri-2016-1200px.jpg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Ashok Vemuri</h2>
								<span class="title white-text">Chief Executive Officer,<br> Conduent, Inc.</span>
							</div>
						</a>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">
						<a href="#" class="director" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/161201_Vincent_Intieri__004_final_1200px.jpg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Vincent J. Intrieri</h2>
								<span class="title white-text">Senior Managing Director,<br> Icahn Capital LP </span>
							</div>
						</a>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">
						<a href="#" class="director" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/161201_Michael_Nevin__001_final_1200px.jpg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Michael Nevin</h2>
								<span class="title white-text">Financial Analyst,<br> Icahn Enterprises LP</span>
							</div>						
						</a>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">
						<a href="#" class="director" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/161201_Bill_Parrett_001_final_1200px.jpg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">William G. Parrett</h2>
								<span class="title white-text">Retired Chief Executive Officer,<br> Deloitte Touche Tohmatsu</span>
							</div>
						</a>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">
						<a href="#" class="director" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/161201_Courtney_Mather__011_final_1200px.jpg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Courtney Mather</h2>
								<span class="title white-text">Managing Director,<br> Icahn Capital LP</span>
							</div>
						</a>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">
						<a href="#" class="director" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/161201_Michael_Nutter__001.jpg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Michael A. Nutter</h2>
								<span class="title white-text">Former Mayor of<br> Philadelphia, Pennsylvania</span>
							</div>						
						</a>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">
						<a href="#" class="director" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/leaders/161201_Virginia_Wilson_001_final_1200px.jpg');">
							<div class="name-title">
								<h2 class="name white-text cwf-margin-bottom-0">Virginia M. Wilson</h2>
								<span class="title white-text">Executive Vice President, Chief Financial Officer, Teachers Insurance and Annuity Association </span>
							</div>						
						</a>
					</div>
				</div>
			</section>
		

			<section class="container-fluid future-leaders half-frost">
				<div class="row">
					<div class="image col-xs-12 visible-xs-block" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-530682631-min.jpg');">
					</div>
					<div class="background col-xs-12 col-sm-6">
						<svg>
							<defs>
								<filter id="blur">
									<feGaussianBlur in="SourceGraphic" stdDeviation="20"></feGaussianBlur>
								</filter>
							</defs>
							<image filter="url(#blur)" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="<?php bloginfo('template_url'); ?>/placeholderdummycontent/corp/GettyImages-530682631-min.jpg" x="0" y="0" height="100%" width="100%" preserveAspectRatio="xMinYMid slice"></image>
						</svg>
					</div>
					<div class="content col-xs-12 col-sm-6">
						<h1 class="white-text cwf-margin-top-0">
							The opportunity to drive the world forward.
						</h1>
						<p class="white-text">
							We’re always looking to add exceptional people to our growing team. If you’re a self-directed professional with a real desire to make a difference in the lives of millions of people every day, then we’d like to meet you.
						</p>
						<a class="btn btn-lg transparent white text-uppercase" href="/jobs/">Explore careers</a>
					</div>
					<div class="image col-sm-6 hidden-xs" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-530682631-min.jpg');">
					</div>
				</div>
			</section>

			<section class="container bottom-articles">
				<div class="row">
					<div class="col-xs-12 col-md-6 article-container">
						<a class="cwf-article-image-left" href="/about/">
							<div class="image col-xs-6" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-652992811-min.jpg');">
							</div>
							<div class="content col-xs-6">
								<hr class="cwf-hr article">
								<h4 class="title">About Us</h4>
								<p class="hidden-xs">We’re the world’s largest business process services company. See what makes us different than the rest.</p>
								<div class="cta link-blue hidden-xs">Learn more</div>
							</div>
						</a>
					</div>
					<div class="col-xs-12 col-md-6 article-container">
						<a class="cwf-article-image-left" href="/innovation/">
							<div class="image col-xs-6" style="background-image: url('<?php bloginfo('template_url') ?>/placeholderdummycontent/corp/GettyImages-541412737-crop.jpg');">
							</div>
							<div class="content col-xs-6">
								<hr class="cwf-hr article">
								<h4 class="title">Innovation</h4>
								<p class="hidden-xs">Innovation is both a discipline and a mindset. Explore our unique approach to creating new solutions and services.</p>
								<div class="cta link-blue hidden-xs">Learn more</div>
							</div>
						</a>
					</div>
				</div>
			</section>
		</main>
	</div>

<?php
get_footer();
